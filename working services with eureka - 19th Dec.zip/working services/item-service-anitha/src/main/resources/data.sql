insert into shopping_item(item_id,item_name,item_desc,item_price) values (111,'thermometer','heath supplies',200.00);
insert into shopping_item(item_id,item_name,item_desc,item_price) values (222,'thermal pad','heath supplies',250.00);
