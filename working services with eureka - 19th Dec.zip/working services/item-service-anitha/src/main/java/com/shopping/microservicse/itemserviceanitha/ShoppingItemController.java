package com.shopping.microservicse.itemserviceanitha;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ShoppingItemController {
    
	@Autowired
    ShoppingItemRepository shoppingItemRepository;
    
	@GetMapping("/items")
	public List<ShoppingItem> getItemDetails() {
		List<ShoppingItem> item = shoppingItemRepository.findAll();
		return item;
		}
	@GetMapping("/item/{itemName}")
	public ShoppingItem getItemByItemName(@PathVariable String itemName) {
	ShoppingItem  item1 = shoppingItemRepository.findByItemName(itemName);
	return item1;
		//return new  ShoppingItem(111L,"thermometer","health supplies",200.00);
	}
}
