package com.payroll.microservices.eurekanamingserver;

//import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaNamingServerApplicationTests {

	//@Test
	void contextLoads() {
	}

}
