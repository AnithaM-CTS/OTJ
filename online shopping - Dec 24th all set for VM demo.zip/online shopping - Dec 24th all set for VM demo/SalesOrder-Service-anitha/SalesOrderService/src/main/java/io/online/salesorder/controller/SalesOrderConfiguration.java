package io.online.salesorder.controller;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@ConfigurationProperties(prefix="sales-order-serviceanitha")
@Component
public class SalesOrderConfiguration {
     private String noCustMessage;
     private String noItemMessage;
	public String getNoCustMessage() {
		return noCustMessage;
	}
	public void setNoCustMessage(String noCustMessage) {
		this.noCustMessage = noCustMessage;
	}
	public String getNoItemMessage() {
		return noItemMessage;
	}
	public void setNoItemMessage(String noItemMessage) {
		this.noItemMessage = noItemMessage;
	}
     
}
